function remigrate()
%REMIGRATE restore original model from migration backup and then migrate again

%restore old model
backupfolder = '.\Migrated\version_800_222038' ;
backupmodel  = 'Demo_LaneKeeping_800_222038_cs' ;
backupfile   = '.\Migrated\version_800_222038\Demo_LaneKeeping_800_222038_cs.mdl' ;
srcfolder    = '.' ;
srcmodel     = 'Demo_LaneKeeping_cs' ;
modelreferencing = 0 ;
mbxutils.backupModel(backupfolder,backupmodel,srcfolder,srcmodel); 
chdir('.');
open_system('Demo_LaneKeeping_cs');

%migrate restored model
migrate_all(srcmodel,modelreferencing,backupfile);
end
